/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package javaprocessbuilder;


//package com.itexpert.exam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class JavaProcessBuilder {
/**
* Provide absolute JAVA file path
*/
    public static StringBuilder builder = new StringBuilder();;
    public static String status;


public static void callme(String nameOfFile) throws IOException
{    String JAVA_FILE_LOCATION = "D:\\";
     JAVA_FILE_LOCATION=JAVA_FILE_LOCATION.concat(nameOfFile);
     JAVA_FILE_LOCATION=JAVA_FILE_LOCATION.concat(".java");

    String command[] = {"javac",JAVA_FILE_LOCATION};
ProcessBuilder processBuilder = new ProcessBuilder(command);

Process process = processBuilder.start();
/**
* Check if any errors or compilation errors encounter then print on Console.
*/

if( process.getErrorStream().read() != -1 ){
print(process.getErrorStream());
status="Compilation Errors";
}
/**
* Check if javac process execute successfully or Not
* 0 - successful
*/
if( process.exitValue() == 0 ){
process = new ProcessBuilder(new String[]{"java","-cp","d:\\",nameOfFile}).start();
/** Check if RuntimeException or Errors encounter during execution then print errors on console
* Otherwise print Output
*/
if( process.getErrorStream().read() != -1 ){
print(process.getErrorStream());
status="Errors ";
}
else{
print(process.getInputStream());
status="Output ";
}

}

}

public static void main(String args[]) throws IOException{
   // String nameOfFile;
    //callme( nameOfFile );
}
public static String getStatus()
{
    return status;
}
public static StringBuilder getOutput()
{
    return builder;
}
public static void print(InputStream input) throws IOException{
BufferedReader in = new BufferedReader(new InputStreamReader(input));

//System.out.println(status);
//getStatus();
String line = null;
while((line = in.readLine()) != null ){
//System.out.println(line);
builder.append(line);
 builder.append(System.getProperty("line.separator"));
}
//in.close();
//getOutput();
}


}